# Cómo instalar "Registro de Campo — Tabaco" en el celular

Esta app puede usarse de **dos formas**. Elige según lo que necesites ahora.

---

## Opción 1 — Usarla ya mismo (sin instalar nada)

1. Copia el archivo `index.html` a tu celular (por WhatsApp, correo o Google Drive).
2. Ábrelo con Chrome.
3. Listo — funciona exactamente igual que hasta ahora. Puedes crear un acceso directo
   desde el menú ⋮ de Chrome → "Agregar a pantalla de inicio".

Esta opción **no necesita internet** para funcionar día a día (excepto el botón
"Descargar en Excel", que la primera vez necesita conexión).

La única limitación: al abrirse como archivo suelto, Android no permite el modo
"app instalada de verdad" (pantalla completa sin barra del navegador, ícono
con el logo de la hoja). Para eso hace falta la Opción 2.

---

## Opción 2 — Instalarla como app de verdad (ícono propio, pantalla completa)

Para esto, los archivos deben estar en una dirección web (https://...), no sueltos
en el celular. La forma más fácil y **gratuita** es GitHub Pages:

### Paso a paso (una sola vez, ~10 minutos)

1. Entra a **github.com** y crea una cuenta gratis (si no tienes una).
2. Crea un repositorio nuevo (botón verde "New"). Le pones un nombre, por ejemplo
   `registro-tabaco`. Que sea **público**. Crea el repositorio.
3. Dentro del repositorio, botón **"uploading an existing file"** (o "Add file" →
   "Upload files").
4. Arrastra estos 5 archivos (los que vienen en esta carpeta):
   - `index.html`
   - `manifest.json`
   - `sw.js`
   - `icon-192.png`
   - `icon-512.png`
5. Click en **"Commit changes"**.
6. Ve a **Settings** (del repositorio) → **Pages** (en el menú de la izquierda).
7. En "Branch", elige `main` y carpeta `/ (root)`. Guarda.
8. Espera 1-2 minutos. GitHub te da una dirección como:
   `https://tu-usuario.github.io/registro-tabaco/`
9. Abre esa dirección en Chrome **desde el celular**.
10. Aparecerá un aviso "Agregar Registro de Campo Tabaco a la pantalla de inicio"
    (o desde el menú ⋮ → "Instalar app"). Acéptalo.

Listo — ahora tienes un ícono propio en el celular, abre a pantalla completa, y
funciona sin internet (excepto la exportación a Excel).

### ¿Y si más adelante quiero un .apk real para instalar manualmente?

Es posible generar un proyecto Android (con la herramienta Capacitor) que empaqueta
esta misma app en un archivo .apk de verdad. El único paso que no puedo hacer yo
es la compilación final, que requiere Android Studio instalado en una computadora
(gratis, se instala una vez). Si llegas a necesitarlo, dímelo y te preparo ese
proyecto completo con instrucciones paso a paso.

---

## Notas importantes

- **Los datos no se comparten entre la Opción 1 y la Opción 2.** Si empezaste a
  registrar datos abriendo el archivo suelto y luego instalas la versión de
  GitHub Pages, son "dos dispositivos" distintos para el navegador. Usa
  **⚙️ Respaldo → Descargar copia (.json)** en la versión vieja y
  **Importar copia** en la nueva para trasladar todo.
- Cada vez que te ayude a mejorar la app, solo necesitas repetir el paso 4
  (subir los archivos nuevos) — el resto no cambia.
